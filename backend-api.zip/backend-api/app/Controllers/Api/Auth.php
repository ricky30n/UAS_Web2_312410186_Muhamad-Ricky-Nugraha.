<?php

namespace App\Controllers\Api;

use CodeIgniter\RESTful\ResourceController;
use App\Models\UserModel;

class Auth extends ResourceController
{
    protected $format = 'json';

    public function login()
    {
        $model = new UserModel();
        
        // Membaca input secara fleksibel (Mendukung getPost, JSON raw, atau URLSearchParams dari Axios)
        $username = $this->request->getVar('username');
        $password = $this->request->getVar('password');

        // Jika request dikirim sebagai raw JSON body, ambil dengan getJSON()
        if (empty($username) || empty($password)) {
            $json = $this->request->getJSON(true);
            if (!empty($json)) {
                $username = $json['username'] ?? null;
                $password = $json['password'] ?? null;
            }
        }

        // Cari user berdasarkan username di database
        $user = $model->where('username', $username)->first();

        if ($user) {
            // Verifikasi password (mendukung teks murni untuk UAS atau hash password_verify)
            if (password_verify($password, $user['password']) || $password === $user['password']) {
                
                // Generate token acak sepanjang 32 bytes untuk tanda pengenal otentikasi
                $token = bin2hex(random_bytes(32));

                // PERBAIKAN: Mengambil nama primary key secara dinamis dari properti model ($model->primaryKey)
                // Ini mencegah error jika kolom ID di database bernama 'id_user', 'id', atau yang lainnya.
                $pk = $model->primaryKey;
                $userId = $user[$pk] ?? $user['id'] ?? null;

                if ($userId) {
                    // Simpan token baru ke database untuk memproteksi session master data
                    $model->update($userId, ['token' => $token]);
                }

                return $this->respond([
                    'status'   => 200,
                    'message'  => 'Login berhasil!',
                    'token'    => $token,
                    'user'     => [
                        'username'     => $user['username'],
                        'nama_lengkap' => $user['nama_lengkap']
                    ]
                ], 200);
            }
        }

        // ===== DEBUG SEMENTARA: hapus blok ini setelah masalah login ketemu =====
        $dbInfo = 'unknown';
        try {
            $dbInfo = \Config\Database::connect()->getDatabase();
        } catch (\Throwable $e) {
            $dbInfo = 'error: ' . $e->getMessage();
        }

        return $this->respond([
            'status'  => 401,
            'debug'   => true,
            'username_diterima' => $username,
            'password_diterima' => $password,
            'user_ditemukan'    => $user ? true : false,
            'password_di_db'    => $user['password'] ?? null,
            'jumlah_user_di_tabel' => $model->countAll(),
            'db_name' => $dbInfo,
        ], 401);
        // ===== AKHIR BLOK DEBUG =====

        // Jika salah kombinasi akun, kembalikan status 401 Unauthorized
        return $this->failUnauthorized('Username atau Password salah.');
    }

    public function logout()
    {
        $model = new UserModel();
        
        // Ambil token dari HTTP Header Authorization
        $authHeader = $this->request->getServer('HTTP_AUTHORIZATION');
        if ($authHeader) {
            $token = str_replace('Bearer ', '', $authHeader);
            
            // Cari user dengan token tersebut dan hapus tokennya (set NULL)
            $user = $model->where('token', $token)->first();
            if ($user) {
                $pk = $model->primaryKey;
                $userId = $user[$pk] ?? $user['id'] ?? null;
                
                if ($userId) {
                    $model->update($userId, ['token' => null]);
                }
            }
        }

        return $this->respond([
            'status'  => 200,
            'message' => 'Logout berhasil, sesi token dihapus!'
        ], 200);
    }
}