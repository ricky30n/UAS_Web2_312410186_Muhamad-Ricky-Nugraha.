<?php

namespace App\Controllers\Api;

use CodeIgniter\RESTful\ResourceController;
use App\Models\BukuModel;

class Buku extends ResourceController
{
    protected $modelName = 'App\Models\BukuModel';
    protected $format    = 'json';

    // 1. GET /api/buku (Mengambil semua data buku) 
    public function index()
    {
        $data = $this->model->findAll();
        return $this->respond($data, 200);
    }

    // 2. GET /api/buku/(:num) (Mengambil satu data buku berdasarkan ID)
    public function show($id = null)
    {
        $data = $this->model->find($id);
        if ($data) {
            return $this->respond($data, 200);
        }
        return $this->failNotFound('Data buku tidak ditemukan.');
    }

    // 3. POST /api/buku (Menambah data buku baru) 
    public function create()
    {
        $rules = [
            'judul_buku' => 'required',
            'genre'      => 'required',
            'penulis'    => 'required',
            'stok'       => 'required|numeric'
        ];

        if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
        }

        $input = $this->request->getPost();
        $this->model->insert($input);
        
        return $this->respondCreated([
            'status'  => 201,
            'message' => 'Data buku berhasil ditambahkan!'
        ]);
    }

    // 4. PUT /api/buku/(:num) (Mengubah data buku) 
    public function update($id = null)
    {
        $input = $this->request->getRawInput();
        $data = $this->model->find($id);

        if (!$data) {
            return $this->failNotFound('Data buku tidak ditemukan.');
        }

        $this->model->update($id, $input);
        return $this->respond([
            'status'  => 200,
            'message' => 'Data buku berhasil diperbarui!'
        ]);
    }

    // 5. DELETE /api/buku/(:num) (Menghapus data buku) 
    public function delete($id = null)
    {
        $data = $this->model->find($id);
        if (!$data) {
            return $this->failNotFound('Data buku tidak ditemukan.');
        }

        $this->model->delete($id);
        return $this->respondDeleted([
            'status'  => 200,
            'message' => 'Data buku berhasil dihapus!'
        ]);
    }
}