<?php

namespace App\Models;

use CodeIgniter\Model;

class BukuModel extends Model
{
    protected $table            = 'buku';
    protected $primaryKey       = 'id_buku';
    protected $useAutoIncrement = true;
    protected $allowedFields    = ['judul_buku', 'genre', 'penulis', 'stok']; // Kolom yang boleh diisi [cite: 19]
}