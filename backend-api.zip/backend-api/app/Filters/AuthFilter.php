<?php

namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use Config\Services; // <-- PERBAIKAN 1: Wajib mengimpor class Services agar Services::response() bisa terbaca
use App\Models\UserModel;

class AuthFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        // Abaikan validasi token jika request berupa OPTIONS (Preflight request dari browser)
        if (strtolower($request->getMethod()) === 'options') {
            return;
        }

        // Ambil token dari HTTP Header 'Authorization Bearer'
        $authHeader = $request->getServer('HTTP_AUTHORIZATION');
        
        if (!$authHeader) {
            return Services::response()
                ->setJSON(['status' => 401, 'message' => 'Token tidak ditemukan. Akses ditolak!'])
                ->setStatusCode(401);
        }

        $token = str_replace('Bearer ', '', $authHeader);
        $userModel = new UserModel();
        
        // Cari token di database
        $user = $userModel->where('token', $token)->first();

        // Jika token kosong atau tidak cocok dengan di DB, kembalikan status 401 Unauthorized
        if (!$user || empty($user['token'])) {
            // PERBAIKAN 2: Menggunakan Services::response() agar konsisten dan menghindari error fungsi global response()
            return Services::response()
                ->setJSON(['status' => 401, 'message' => 'Sesi habis atau Token tidak valid!'])
                ->setStatusCode(401);
        }
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // Tidak perlu penanganan khusus setelah request
    }
}