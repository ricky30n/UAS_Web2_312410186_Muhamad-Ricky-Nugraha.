<?php

use CodeIgniter\Router\RouteCollection;

/** @var RouteCollection $routes */
$routes->get('/', 'Home::index');

// SATUKAN SEMUA ENDPOINT API KE DALAM SATU GRUP SAJA
$routes->group('api', function($routes) {
    // 1. Route Otentikasi (Login & Logout)
    $routes->post('login', 'Api\Auth::login');
    $routes->post('logout', 'Api\Auth::logout');

    // 2. Route RESTful Resource CRUD Buku (Otomatis melayani GET, POST, PUT, DELETE)
    $routes->resource('buku', ['controller' => 'Api\Buku']);
});