// 1. Import komponen halaman modular
import Home from './components/Home.js';
import Login from './components/Login.js';
import Dashboard from './components/Dashboard.js';
import Buku from './components/Buku.js';

// PERBAIKAN DARURAT: Mengubah localhost ke IP 127.0.0.1 dan menyertakan index.php 
// untuk menghindari hambatan mapping DNS Windows atau masalah port Apache.
const API_URL = 'http://127.0.0.1/UAS_Web2_312410186_ricky/backend-api/public/index.php/api';

// 2. Konfigurasi Rute Aplikasi (Vue Router berbasis SPA)
const routes = [
    { path: '/', component: Home, name: 'home' },
    { path: '/login', component: Login, name: 'login' },
    { 
        path: '/dashboard', 
        component: Dashboard, 
        name: 'dashboard',
        meta: { requiresAuth: true } // Menandakan halaman ini butuh login [cite: 43]
    },
    { 
        path: '/buku', 
        component: Buku, 
        name: 'buku',
        meta: { requiresAuth: true } // Menandakan halaman ini butuh login [cite: 43]
    }
];

const router = VueRouter.createRouter({
    history: VueRouter.createWebHashHistory(),
    routes
});

// 3. Client-Side Security: Navigation Guards [cite: 41]
router.beforeEach((to, from, next) => {
    const isLoggedIn = localStorage.getItem('isLoggedIn'); // Ambil status login [cite: 34]

    // Jika rute yang dituju memerlukan otentikasi dan user belum login [cite: 43, 44]
    if (to.matched.some(record => record.meta.requiresAuth) && !isLoggedIn) {
        alert('Akses Ditolak! Anda harus login terlebih dahulu.');
        next({ name: 'login' }); // Tendang otomatis ke halaman login [cite: 44]
    } else {
        next(); // Izinkan akses jika sudah login atau rute public
    }
});

// 4. Otomatisasi Token: Axios Request Interceptor [cite: 45]
axios.interceptors.request.use(
    (config) => {
        const token = localStorage.getItem('token'); // Ambil token dari localStorage [cite: 34, 46]
        if (token) {
            // Suntikkan token ke dalam header HTTP Request secara otomatis [cite: 46]
            config.headers['Authorization'] = `Bearer ${token}`;
        }
        return config;
    },
    (error) => {
        return Promise.reject(error);
    }
);

// 5. Otomatisasi Token: Axios Response Interceptor [cite: 45]
axios.interceptors.response.use(
    (response) => {
        return response;
    },
    (error) => {
        // Tangkap error 401 Unauthorized secara global (Sesi Habis / Token Tidak Valid)
        // Kecualikan request ke endpoint /login: 401 di sana berarti salah username/password,
        // bukan sesi habis, dan pesannya sudah ditangani sendiri oleh Login.js
        const isLoginRequest = error.config && error.config.url && error.config.url.includes('/login');

        if (error.response && error.response.status === 401 && !isLoginRequest) {
            alert('Sesi Anda telah habis atau token tidak valid. Silakan login kembali.'); // Munculkan alert [cite: 48]
            
            // Bersihkan sesi di localStorage [cite: 35]
            localStorage.removeItem('isLoggedIn');
            localStorage.removeItem('token');
            localStorage.removeItem('user');
            
            // Tendang pengguna kembali ke form login [cite: 48]
            window.location.href = '#/login';
        }
        return Promise.reject(error);
    }
);

// 6. Inisialisasi Aplikasi Vue 3
const app = Vue.createApp({});
app.use(router);
app.mount('#app');

// Ekspor API_URL agar bisa dipakai di file komponen lain
export { API_URL };