import { API_URL } from '../app.js';

export default {
    template: `
        <div class="min-h-screen bg-slate-50 flex">
            <aside class="w-64 bg-slate-900 text-slate-200 flex flex-col justify-between hidden md:flex">
                <div class="p-6">
                    <div class="flex items-center space-x-3 mb-8">
                        <span class="text-3xl">📚</span>
                        <span class="text-lg font-bold text-white tracking-tight">Admin E-Library</span>
                    </div>
                    <nav class="space-y-2">
                        <router-link to="/dashboard" class="flex items-center space-x-3 px-4 py-2.5 rounded-xl text-slate-400 hover:bg-slate-800 hover:text-slate-200 transition">
                            <span>📊</span> <span>Dashboard Utama</span>
                        </router-link>
                        <router-link to="/buku" class="flex items-center space-x-3 px-4 py-2.5 rounded-xl bg-indigo-600 text-white font-medium transition">
                            <span>📖</span> <span>Kelola Data Buku</span>
                        </router-link>
                    </nav>
                </div>
                
                <div class="p-6 border-t border-slate-800">
                    <button @click="handleLogout" class="w-full bg-rose-600/20 hover:bg-rose-600 text-rose-400 hover:text-white px-4 py-2.5 rounded-xl text-sm font-medium transition duration-150 flex items-center justify-center space-x-2 cursor-pointer">
                        <span>🚪</span> <span>Keluar Sesi</span>
                    </button>
                </div>
            </aside>

            <div class="flex-1 flex flex-col min-w-0 overflow-hidden">
                <header class="bg-white border-b border-slate-200 px-6 py-4 flex justify-between items-center shadow-sm">
                    <h1 class="text-xl font-bold text-slate-800 flex items-center space-x-2">
                        <span>📖</span> <span>Manajemen Master Data Buku</span>
                    </h1>
                    <button @click="openAddModal" class="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-xl text-sm font-medium transition duration-150 shadow-sm flex items-center space-x-2 cursor-pointer">
                        <span>➕</span> <span>Tambah Buku</span>
                    </button>
                </header>

                <main class="flex-1 overflow-y-auto p-6 max-w-7xl w-full mx-auto">
                    <div class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
                        <div class="overflow-x-auto">
                            <table class="w-full text-left border-collapse">
                                <thead>
                                    <tr class="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-500 uppercase tracking-wider">
                                        <th class="px-6 py-4">Judul Buku</th>
                                        <th class="px-6 py-4">Genre / Genre Kategori</th>
                                        <th class="px-6 py-4">Penulis</th>
                                        <th class="px-6 py-4 text-center">Stok Koleksi</th>
                                        <th class="px-6 py-4 text-center">Aksi Operasi</th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-slate-200 text-sm text-slate-600">
                                    <tr v-for="buku in listBuku" :key="buku.id_buku" class="hover:bg-slate-50/50 transition">
                                        <td class="px-6 py-4 font-medium text-slate-900">{{ buku.judul_buku }}</td>
                                        <td class="px-6 py-4">
                                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-50 text-indigo-700">
                                                {{ buku.genre }}
                                            </span>
                                        </td>
                                        <td class="px-6 py-4">{{ buku.penulis }}</td>
                                        <td class="px-6 py-4 text-center font-semibold" :class="buku.stok > 0 ? 'text-emerald-600' : 'text-rose-600'">
                                            {{ buku.stok }}
                                        </td>
                                        <td class="px-6 py-4 text-center space-x-2">
                                            <button @click="openEditModal(buku)" class="text-indigo-600 hover:text-indigo-900 bg-indigo-50 hover:bg-indigo-100 px-2.5 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer">
                                                ✏️ Edit
                                            </button>
                                            <button @click="deleteBuku(buku.id_buku)" class="text-rose-600 hover:text-rose-900 bg-rose-50 hover:bg-rose-100 px-2.5 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer">
                                                🗑️ Hapus
                                            </button>
                                        </td>
                                    </tr>
                                    <tr v-if="listBuku.length === 0">
                                        <td colspan="5" class="px-6 py-12 text-center text-slate-400">
                                            Belum ada koleksi buku. Silakan klik tombol Tambah Buku.
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </main>
            </div>

            <div v-if="isModalOpen" class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
                <div class="bg-white rounded-2xl max-w-md w-full p-6 shadow-xl border border-slate-100 animate-in fade-in zoom-in-95 duration-150">
                    <div class="flex justify-between items-center border-b border-slate-200 pb-3 mb-4">
                        <h3 class="text-lg font-bold text-slate-900">
                            {{ isEditMode ? 'Ubah Informasi Buku' : 'Tambah Koleksi Buku Digital Baru' }}
                        </h3>
                        <button @click="closeModal" class="text-slate-400 hover:text-slate-600 text-xl cursor-pointer">&times;</button>
                    </div>

                    <form @submit.prevent="saveBuku" class="space-y-4">
                        <div>
                            <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">Judul Buku</label>
                            <input v-model="form.judul_buku" type="text" required class="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
                        </div>
                        <div>
                            <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">Genre Kategori</label>
                            <input v-model="form.genre" type="text" required placeholder="Contoh: Komik, Novel, Sci-Fi" class="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
                        </div>
                        <div>
                            <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">Penulis / Penerbit</label>
                            <input v-model="form.penulis" type="text" required class="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
                        </div>
                        <div>
                            <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">Jumlah Stok Koleksi</label>
                            <input v-model="form.stok" type="number" required min="0" class="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
                        </div>

                        <div class="flex justify-end space-x-3 pt-4 border-t border-slate-100 mt-6">
                            <button type="button" @click="closeModal" class="px-4 py-2 border border-slate-300 text-slate-700 text-sm font-medium rounded-xl hover:bg-slate-50 transition cursor-pointer">
                                Batal
                            </button>
                            <button type="submit" class="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-medium rounded-xl shadow-sm transition cursor-pointer">
                                {{ isEditMode ? 'Perbarui Data' : 'Simpan Koleksi' }}
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    `,
    data() {
        return {
            listBuku: [],
            isModalOpen: false,
            isEditMode: false,
            currentId: null,
            form: {
                judul_buku: '',
                genre: '',
                penulis: '',
                stok: 0
            }
        }
    },
    mounted() {
        this.fetchBuku();
    },
    methods: {
        // 1. Ambil Data (GET /api/buku) [cite: 25]
        async fetchBuku() {
            try {
                const response = await axios.get(`${API_URL}/buku`);
                this.listBuku = response.data;
            } catch (error) {
                console.error("Gagal memuat data buku:", error);
            }
        },

        // Atur Modal Box [cite: 50, 68]
        openAddModal() {
            this.isEditMode = false;
            this.currentId = null;
            this.form = { judul_buku: '', genre: '', penulis: '', stok: 0 };
            this.isModalOpen = true;
        },
        openEditModal(buku) {
            this.isEditMode = true;
            this.currentId = buku.id_buku;
            this.form = { ...buku };
            this.isModalOpen = true;
        },
        closeModal() {
            this.isModalOpen = false;
        },

        // 2. Simpan atau Update Data (POST / PUT) [cite: 25]
        async saveBuku() {
            try {
                if (this.isEditMode) {
                    // Update Data via Axios PUT [cite: 11, 25]
                    // Menggunakan URLSearchParams agar serasi dengan getRawInput() CodeIgniter 4
                    const params = new URLSearchParams();
                    params.append('judul_buku', this.form.judul_buku);
                    params.append('genre', this.form.genre);
                    params.append('penulis', this.form.penulis);
                    params.append('stok', this.form.stok);

                    const response = await axios.put(`${API_URL}/buku/${this.currentId}`, params);
                    alert(response.data.message);
                } else {
                    // Tambah Data Baru via Axios POST [cite: 11, 25]
                    const formData = new FormData();
                    formData.append('judul_buku', this.form.judul_buku);
                    formData.append('genre', this.form.genre);
                    formData.append('penulis', this.form.penulis);
                    formData.append('stok', this.form.stok);

                    const response = await axios.post(`${API_URL}/buku`, formData);
                    alert(response.data.message);
                }
                this.closeModal();
                this.fetchBuku(); // Refresh tabel setelah operasi CRUD berhasil
            } catch (error) {
                console.error("Operasi simpan data gagal:", error);
                alert("Gagal memproses data. Periksa token otentikasi Anda.");
            }
        },

        // 3. Hapus Data (DELETE /api/buku/:id) [cite: 25]
        async deleteBuku(id) {
            if (confirm("Apakah Anda yakin ingin menghapus data master koleksi buku ini?")) {
                try {
                    const response = await axios.delete(`${API_URL}/buku/${id}`);
                    alert(response.data.message);
                    this.fetchBuku(); // Refresh data tabel
                } catch (error) {
                    console.error("Gagal menghapus data:", error);
                    alert("Proses hapus ditolak oleh server.");
                }
            }
        },

        // Sesi Keluar Admin [cite: 35, 56]
        async handleLogout() {
            try {
                await axios.post(`${API_URL}/logout`);
            } catch (error) {
                console.error("Sesi token bermasalah:", error);
            } finally {
                localStorage.clear(); // Bersihkan sesi lokal [cite: 35]
                this.$router.push({ name: 'login' }); // Tendang ke form login [cite: 44]
            }
        }
    }
};