import { API_URL } from '../app.js';

export default {
    template: `
        <div class="min-h-screen bg-slate-50 flex">
            <aside class="w-64 bg-slate-900 text-slate-200 flex flex-col justify-between hidden md:flex">
                <div class="p-6">
                    <div class="flex items-center space-x-3 mb-8">
                        <span class="text-3xl">📚</span>
                        <span class="text-lg font-bold text-white tracking-tight">Admin E-Library</span>
                    </div>
                    <nav class="space-y-2">
                        <router-link to="/dashboard" class="flex items-center space-x-3 px-4 py-2.5 rounded-xl bg-indigo-600 text-white font-medium transition">
                            <span>📊</span> <span>Dashboard Utama</span>
                        </router-link>
                        <router-link to="/buku" class="flex items-center space-x-3 px-4 py-2.5 rounded-xl hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition">
                            <span>📖</span> <span>Kelola Data Buku</span>
                        </router-link>
                    </nav>
                </div>
                <div class="p-6 border-t border-slate-800">
                    <div class="mb-4">
                        <p class="text-xs text-slate-500 uppercase font-semibold">Petugas</p>
                        <p class="text-sm font-medium text-white">{{ user.nama_lengkap }}</p>
                    </div>
                    <button @submit.prevent="handleLogout" @click="handleLogout" class="w-full bg-rose-600/20 hover:bg-rose-600 text-rose-400 hover:text-white px-4 py-2.5 rounded-xl text-sm font-medium transition duration-150 flex items-center justify-center space-x-2 cursor-pointer">
                        <span>🚪</span> <span>Keluar Sistem</span>
                    </button>
                </div>
            </aside>

            <div class="flex-1 flex flex-col min-w-0 overflow-hidden">
                <header class="bg-white border-b border-slate-200 px-6 py-4 flex justify-between items-center">
                    <h1 class="text-xl font-bold text-slate-800">Ringkasan Sistem</h1>
                    <div class="flex items-center space-x-4 md:hidden">
                        <button @click="handleLogout" class="text-sm font-medium text-rose-600 hover:underline">Logout</button>
                    </div>
                </header>

                <main class="flex-1 overflow-y-auto p-6 max-w-7xl w-full mx-auto">
                    <div class="bg-gradient-to-r from-indigo-600 to-violet-600 rounded-2xl p-6 text-white shadow-sm mb-8">
                        <h2 class="text-2xl font-bold">Halo, {{ user.nama_lengkap }}! 👋</h2>
                        <p class="text-indigo-100 mt-1 text-sm md:text-base">
                            Anda masuk sebagai Administrator. Di panel ini Anda dapat mengoperasikan form input, mengedit data, dan menghapus data master koleksi buku digital.
                        </p>
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
                        <div class="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 flex flex-col justify-between">
                            <div>
                                <span class="text-3xl p-3 bg-indigo-50 text-indigo-600 rounded-xl inline-block mb-4">📖</span>
                                <h3 class="text-lg font-bold text-slate-900">Modul Buku & Komik</h3>
                                <p class="text-sm text-slate-500 mt-1">Lakukan penambahan judul baru, update genre, edit info penulis, hingga kontrol sisa stok pustaka digital.</p>
                            </div>
                            <div class="mt-6">
                                <router-link to="/buku" class="inline-flex items-center text-sm font-medium text-indigo-600 hover:text-indigo-500 transition">
                                    Buka Manajemen Buku &rarr;
                                </router-link>
                            </div>
                        </div>

                        <div class="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 flex flex-col justify-between">
                            <div>
                                <span class="text-3xl p-3 bg-emerald-50 text-emerald-600 rounded-xl inline-block mb-4">🌐</span>
                                <h3 class="text-lg font-bold text-slate-900">Lihat Tampilan Publik</h3>
                                <p class="text-sm text-slate-500 mt-1">Periksa ringkasan data katalog terbuka yang saat ini sedang dilihat oleh pengunjung umum atau pembaca luar.</p>
                            </div>
                            <div class="mt-6">
                                <router-link to="/" class="inline-flex items-center text-sm font-medium text-emerald-600 hover:text-emerald-500 transition">
                                    Lihat Beranda Umum &rarr;
                                </router-link>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
        </div>
    `,
    data() {
        return {
            // Ambil data profil user dari localStorage yang disimpan saat login sukses
            user: JSON.parse(localStorage.getItem('user')) || { username: 'Admin', nama_lengkap: 'Administrator' }
        }
    },
    methods: {
        async handleLogout() {
            try {
                // Tembak API logout backend untuk membersihkan sesi token di server database
                await axios.post(`${API_URL}/logout`);
            } catch (error) {
                console.error("Sesi server sudah kadaluarsa atau bermasalah:", error);
            } finally {
                // Sesuai ketentuan: Menghapus seluruh sesi token di penyimpanan lokal browser secara aman
                localStorage.removeItem('isLoggedIn');
                localStorage.removeItem('token');
                localStorage.removeItem('user');

                // Alihkan ke halaman login secara asynchronous (SPA) tanpa hard-reload
                this.$router.push({ name: 'login' });
            }
        }
    }
};