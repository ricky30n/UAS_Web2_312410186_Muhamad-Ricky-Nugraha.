import { API_URL } from '../app.js';

export default {
    template: `
        <div class="min-h-screen bg-slate-50">
            <!-- Navbar Modern bertenaga TailwindCSS -->
            <nav class="bg-white shadow-sm border-b border-slate-200">
                <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div class="flex justify-between h-16 items-center">
                        <div class="flex items-center space-x-2">
                            <span class="text-2xl">📚</span>
                            <span class="text-xl font-bold text-indigo-600 tracking-tight">E-Library Digital</span>
                        </div>
                        <div>
                            <!-- Tombol Dinamis Tergantung Status Login -->
                            <router-link v-if="!isLoggedIn" to="/login" class="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition duration-150 shadow-sm">
                                Masuk Admin
                            </router-link>
                            <router-link v-else to="/dashboard" class="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition duration-150 shadow-sm">
                                Ke Dashboard
                            </router-link>
                        </div>
                    </div>
                </div>
            </nav>

            <!-- Hero Section -->
            <header class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 text-center">
                <h1 class="text-4xl font-extrabold text-slate-900 tracking-tight sm:text-5xl">
                    Selamat Datang di <span class="text-indigo-600">E-Library</span>
                </h1>
                <p class="mt-4 text-lg text-slate-600 max-w-2xl mx-auto">
                    Platform sistem informasi peminjaman komik dan buku digital secara mandiri, cepat, dan terintegrasi.
                </p>
            </header>

            <!-- Widget Ringkasan Total Data (Sesuai Syarat User Matrix Public) -->
            <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-16">
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
                    <div class="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 flex items-center space-x-4">
                        <div class="p-3 bg-indigo-50 text-indigo-600 rounded-xl text-2xl">📖</div>
                        <div>
                            <p class="text-sm font-medium text-slate-500">Total Koleksi Buku</p>
                            <p class="text-2xl font-bold text-slate-900">{{ listBuku.length }} Judul</p>
                        </div>
                    </div>
                    <div class="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 flex items-center space-x-4">
                        <div class="p-3 bg-emerald-50 text-emerald-600 rounded-xl text-2xl">✓</div>
                        <div>
                            <p class="text-sm font-medium text-slate-500">Tersedia untuk Dipinjam</p>
                            <p class="text-2xl font-bold text-slate-900">{{ totalStok }} Eksemplar</p>
                        </div>
                    </div>
                    <div class="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 flex items-center space-x-4">
                        <div class="p-3 bg-amber-50 text-amber-600 rounded-xl text-2xl">👥</div>
                        <div>
                            <p class="text-sm font-medium text-slate-500">Akses Publik</p>
                            <p class="text-2xl font-bold text-slate-900">Aktif</p>
                        </div>
                    </div>
                </div>

                <!-- Tabel Katalog Buku Terbuka (Menggunakan Class Utility TailwindCSS) -->
                <div class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
                    <div class="px-6 py-5 border-b border-slate-200">
                        <h3 class="text-lg font-semibold text-slate-900">Katalog Buku Digital Terkini</h3>
                    </div>
                    <div class="overflow-x-auto">
                        <table class="w-full text-left border-collapse">
                            <thead>
                                <tr class="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-500 uppercase tracking-wider">
                                    <th class="px-6 py-4">Judul Buku</th>
                                    <th class="px-6 py-4">Genre / Kategori</th>
                                    <th class="px-6 py-4">Penulis</th>
                                    <th class="px-6 py-4 text-center">Sisa Stok</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-200 text-sm text-slate-600">
                                <tr v-for="buku in listBuku" :key="buku.id_buku" class="hover:bg-slate-50/70 transition">
                                    <td class="px-6 py-4 font-medium text-slate-900">{{ buku.judul_buku }}</td>
                                    <td class="px-6 py-4">
                                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-50 text-indigo-700">
                                            {{ buku.genre }}
                                        </span>
                                    </td>
                                    <td class="px-6 py-4">{{ buku.penulis }}</td>
                                    <td class="px-6 py-4 text-center font-semibold" :class="buku.stok > 0 ? 'text-emerald-600' : 'text-rose-600'">
                                        {{ buku.stok }}
                                    </td>
                                </tr>
                                <tr v-if="listBuku.length === 0">
                                    <td colspan="4" class="px-6 py-10 text-center text-slate-400">
                                        Belum ada koleksi buku yang terdata di sistem.
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </main>
        </div>
    `,
    data() {
        return {
            listBuku: [],
            isLoggedIn: localStorage.getItem('isLoggedIn') === 'true'
        }
    },
    computed: {
        totalStok() {
            // Menghitung total akumulasi stok buku yang tersedia secara dinamis
            return this.listBuku.reduce((acc, curr) => acc + parseInt(curr.stok || 0), 0);
        }
    },
    mounted() {
        this.fetchKatalogBuku();
    },
    methods: {
        async fetchKatalogBuku() {
            try {
                // Tembak RESTful API endpoint GET /api/buku (Public Tanpa Token)
                const response = await axios.get(`${API_URL}/buku`);
                this.listBuku = response.data;
            } catch (error) {
                console.error("Gagal mengambil katalog buku:", error);
            }
        }
    }
};