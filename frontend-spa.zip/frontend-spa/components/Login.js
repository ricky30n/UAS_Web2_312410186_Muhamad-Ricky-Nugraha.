import { API_URL } from '../app.js';

export default {
    template: `
        <div class="min-h-screen flex items-center justify-center bg-slate-100 px-4 sm:px-6 lg:px-8">
            <div class="max-w-md w-full space-y-8 bg-white p-8 rounded-2xl shadow-md border border-slate-200">
                <div>
                    <div class="text-center text-4xl mb-2">🔒</div>
                    <h2 class="text-center text-3xl font-extrabold text-slate-900 tracking-tight">
                        Masuk Administrator
                    </h2>
                    <p class="mt-2 text-center text-sm text-slate-600">
                        Sistem Informasi E-Library Digital
                    </p>
                </div>
                
                <form class="mt-8 space-y-6" @submit.prevent="handleLogin">
                    <div class="rounded-md shadow-sm space-y-4">
                        <div>
                            <label for="username" class="block text-sm font-medium text-slate-700 mb-1">Username</label>
                            <input id="username" v-model="username" type="text" required 
                                class="appearance-none rounded-lg relative block w-full px-3 py-2 border border-slate-300 placeholder-slate-400 text-slate-900 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 text-sm" 
                                placeholder="Masukkan username admin">
                        </div>
                        <div>
                            <label for="password" class="block text-sm font-medium text-slate-700 mb-1">Password</label>
                            <input id="password" v-model="password" type="password" required 
                                class="appearance-none rounded-lg relative block w-full px-3 py-2 border border-slate-300 placeholder-slate-400 text-slate-900 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 text-sm" 
                                placeholder="••••••••">
                        </div>
                    </div>

                    <div v-if="errorMessage" class="bg-rose-50 border border-rose-200 text-rose-700 px-4 py-2 rounded-lg text-sm">
                        {{ errorMessage }}
                    </div>

                    <div>
                        <button type="submit" :disabled="loading"
                            class="group relative w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-lg text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition duration-150 shadow-sm disabled:opacity-50">
                            <span v-if="loading">Memproses...</span>
                            <span v-else>Masuk ke Sistem</span>
                        </button>
                    </div>
                </form>
                
                <div class="text-center">
                    <router-link to="/" class="text-sm font-medium text-indigo-600 hover:text-indigo-500 transition">
                        ← Kembali ke Beranda Utama
                    </router-link>
                </div>
            </div>
        </div>
    `,
    data() {
        return {
            username: '',
            password: '',
            errorMessage: '',
            loading: false
        }
    },
    methods: {
        async handleLogin() {
            this.loading = true;
            this.errorMessage = '';
            
            // Siapkan payload data form login menggunakan URLSearchParams agar serasi dengan RESTful API backend
            const params = new URLSearchParams();
            params.append('username', this.username);
            params.append('password', this.password);

            try {
                // Menembak fungsi API via Axios POST menuju server backend
                const response = await axios.post(`${API_URL}/login`, params);
                
                if (response.data.status === 200) {
                    // Menyimpan tanda pengenal login (isLoggedIn) dan token otentikasi ke dalam localStorage
                    localStorage.setItem('isLoggedIn', 'true');
                    localStorage.setItem('token', response.data.token);
                    localStorage.setItem('user', JSON.stringify(response.data.user));
                    
                    // Alihkan halaman ke Dashboard Admin secara asinkronus (SPA)
                    this.$router.push({ name: 'dashboard' });
                }
            } catch (error) {
                // Tangkap respon error jika otentikasi gagal sesuai format bawaan CI4
                if (error.response && error.response.data) {
                    this.errorMessage = error.response.data.message || 'Username atau Password salah.';
                } else {
                    this.errorMessage = 'Tidak dapat terhubung ke server backend.';
                }
            } finally {
                this.loading = false;
            }
        }
    }
};